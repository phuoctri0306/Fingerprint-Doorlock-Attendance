#ifndef TIME_MANAGER_H
#define TIME_MANAGER_H

#include <Arduino.h>
#include "time.h"
#include <Preferences.h>
#include "Config.h"

class TimeManager {
private:
  int checkStartHour;
  int checkStartMin;
  int checkLateHour;
  int checkLateMin;
  int checkEndHour;
  int checkEndMin;
  Preferences prefs;
  
public:
  TimeManager();
  
  void setup();
  void loadSettings();
  void saveSettings();
  
  String getTimeStr();
  String getDateStr();
  String getDayOfWeek();
  int getHourNow();
  int getMinuteNow();
  int getDateCode();
  
  void setTimeSettings(int sh, int sm, int lh, int lm, int eh, int em);
  int getStartHour() const { return checkStartHour; }
  int getStartMin() const { return checkStartMin; }
  int getLateHour() const { return checkLateHour; }
  int getLateMin() const { return checkLateMin; }
  int getEndHour() const { return checkEndHour; }
  int getEndMin() const { return checkEndMin; }
  
  bool isBeforeStartTime();
  bool isAfterEndTime();
  bool isLateTime();
};

#endif