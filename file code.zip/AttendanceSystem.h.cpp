#ifndef ATTENDANCE_SYSTEM_H
#define ATTENDANCE_SYSTEM_H

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Keypad.h>
#include <Preferences.h>
#include <WebServer.h>
#include "Config.h"

// Forward declarations
class WiFiManagerCustom;
class FingerprintManager;
class DoorController;
class UserManager;
class TimeManager;
class WebInterface;

class AttendanceSystem {
private:
  // Components
  LiquidCrystal_I2C* lcd;
  Keypad* keypad;
  WiFiManagerCustom* wifiManager;
  FingerprintManager* fingerManager;
  DoorController* doorController;
  UserManager* userManager;
  TimeManager* timeManager;
  WebInterface* webInterface;
  
  // Runtime variables
  String enteredPIN;
  bool waitingA;
  bool enrollActive;
  int enrollIndex;
  int enrollFID;
  int enrollStage;
  unsigned long enrollStageStart;
  bool waitForFinger;
  int waitUserIndex;
  unsigned long waitStartMs;
  unsigned long lcdTimer;
  
  // Button state
  bool isLocked;
  bool lastStable;
  bool lastRaw;
  unsigned long lastDebounce;
  
public:
  AttendanceSystem();
  ~AttendanceSystem();
  
  void setup();
  void loop();
  
  // Public getters for components
  LiquidCrystal_I2C* getLCD() { return lcd; }
  Keypad* getKeypad() { return keypad; }
  WiFiManagerCustom* getWiFiManager() { return wifiManager; }
  FingerprintManager* getFingerManager() { return fingerManager; }
  DoorController* getDoorController() { return doorController; }
  UserManager* getUserManager() { return userManager; }
  TimeManager* getTimeManager() { return timeManager; }
  WebInterface* getWebInterface() { return webInterface; }
  
  // Main handlers
  void handleKeypad(char key);
  void processEnrollment();
  void handleButton();
  void updateLCD();
  
private:
  void setupPins();
  void setupComponents();
  void loadSettings();
};

#endif