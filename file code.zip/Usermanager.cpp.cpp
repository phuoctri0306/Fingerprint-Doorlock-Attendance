#include "UserManager.h"
#include "DoorController.h"
#include "TimeManager.h"

UserManager::UserManager() : userCount(0) {}

void UserManager::loadFromPrefs() {
  prefs.begin("attendance", false);
  userCount = prefs.getInt("user_count", 0);
  if (userCount < 0 || userCount > MAX_USERS) userCount = 0;
  for (int i = 0; i < userCount; i++) {
    users[i].name = prefs.getString(("u_name_" + String(i)).c_str(), "");
    users[i].pin = prefs.getString(("u_pin_" + String(i)).c_str(), "");
    users[i].fid = prefs.getInt(("u_fid_" + String(i)).c_str(), -1);
    users[i].lastCheckDate = prefs.getInt(("u_lastd_" + String(i)).c_str(), 0);
  }
  prefs.end();

  if (userCount == 0) {
    createDefaultUsers();
    saveToPrefs();
  }
}

void UserManager::saveToPrefs() {
  prefs.begin("attendance", false);
  prefs.putInt("user_count", userCount);
  for (int i = 0; i < userCount; i++) {
    prefs.putString(("u_name_" + String(i)).c_str(), users[i].name);
    prefs.putString(("u_pin_" + String(i)).c_str(), users[i].pin);
    prefs.putInt(("u_fid_" + String(i)).c_str(), users[i].fid);
    prefs.putInt(("u_lastd_" + String(i)).c_str(), users[i].lastCheckDate);
  }
  prefs.end();
}

void UserManager::createDefaultUsers() {
  users[0] = {"Nguyen Van A", "12345", 1, 0};
  users[1] = {"Tran Thi B", "23456", 2, 0};
  users[2] = {"Le Van C", "34567", 3, 0};
  users[3] = {"Pham Thi D", "45678", 4, 0};
  users[4] = {"Admin", "00000", -1, 0};
  userCount = 5;
}

int UserManager::findUserByPin(const String &pin) const {
  for (int i = 0; i < userCount; i++) {
    if (users[i].pin == pin) {
      return i;
    }
  }
  return -1;
}

int UserManager::findUserByFingerId(int fid) const {
  for (int i = 0; i < userCount; i++) {
    if (users[i].fid == fid) {
      return i;
    }
  }
  return -1;
}

void UserManager::updateUserLastDate(int index, int date) {
  if (index >= 0 && index < userCount) {
    users[index].lastCheckDate = date;
    saveToPrefs();
  }
}

void UserManager::setUserFingerprint(int index, int fid) {
  if (index >= 0 && index < userCount) {
    users[index].fid = fid;
    saveToPrefs();
  }
}

bool UserManager::addUser(const String &name, const String &pin) {
  if (userCount >= MAX_USERS) return false;
  // Check duplicate pin
  for (int i = 0; i < userCount; i++) {
    if (users[i].pin == pin) return false;
  }
  users[userCount].name = name;
  users[userCount].pin = pin;
  users[userCount].fid = -1;
  users[userCount].lastCheckDate = 0;
  userCount++;
  saveToPrefs();
  return true;
}

bool UserManager::deleteUser(int index) {
  if (index < 0 || index >= userCount) return false;
  for (int i = index; i < userCount - 1; i++) {
    users[i] = users[i + 1];
  }
  userCount--;
  saveToPrefs();
  return true;
}

int UserManager::getNextAvailableFID() const {
  for (int candidate = 1; candidate <= 125; candidate++) {
    bool used = false;
    for (int i = 0; i < userCount; i++) {
      if (users[i].fid == candidate) {
        used = true;
        break;
      }
    }
    if (!used) return candidate;
  }
  return -1;
}

void UserManager::processFingerprintAccess(int userIndex, int scannedFID, DoorController* doorController, TimeManager* timeManager) {
  // This function is called when a fingerprint is scanned during access
  // The actual logic is in the main loop, so we leave it empty here
}