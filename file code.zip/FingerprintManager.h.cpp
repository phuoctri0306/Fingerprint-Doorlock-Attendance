#ifndef FINGERPRINT_MANAGER_H
#define FINGERPRINT_MANAGER_H

#include <Arduino.h>
#include <Adafruit_Fingerprint.h>

#define RXD2 16
#define TXD2 17

class FingerprintManager {
private:
  Adafruit_Fingerprint finger;
  
public:
  FingerprintManager();
  
  bool begin();
  int getFingerprintID();
  bool enrollFingerprint(int id, const String &userName);
  bool deleteFingerprint(int id);
  bool verifyPassword();
  
private:
  uint8_t waitForFinger(uint16_t timeout = 10000);
};

#endif