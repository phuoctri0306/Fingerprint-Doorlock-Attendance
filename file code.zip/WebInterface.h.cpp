#ifndef WEB_INTERFACE_H
#define WEB_INTERFACE_H

#include <WebServer.h>
#include "UserManager.h"
#include "DoorController.h"
#include "TimeManager.h"

class WebInterface {
private:
  WebServer server;
  UserManager* userManager;
  DoorController* doorController;
  TimeManager* timeManager;
  
public:
  WebInterface(UserManager* um, DoorController* dc, TimeManager* tm);
  
  void setup();
  void handleClient();
  
private:
  String htmlHeader(const String &title = "Admin");
  String htmlFooter();
  
  void handleRoot();
  void handleAdmin();
  void handleAddUser();
  void handleDeleteUser();
  void handleEnroll();
  void handleWifiPage();
  void handleWifiSave();
  void handleSetTime();
};

#endif