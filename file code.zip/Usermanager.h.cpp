#ifndef USER_MANAGER_H
#define USER_MANAGER_H

#include <Arduino.h>
#include <Preferences.h>
#include "Config.h"

// Forward declaration
class DoorController;
class TimeManager;

struct User {
  String name;
  String pin; // length PIN_LENGTH
  int fid;    // -1 = not set; otherwise fingerprint ID (>=1)
  int lastCheckDate; // YYYYMMDD or 0
};

class UserManager {
private:
  User users[MAX_USERS];
  int userCount;
  Preferences prefs;

public:
  UserManager();
  
  void loadFromPrefs();
  void saveToPrefs();
  
  int getUserCount() const { return userCount; }
  String getUserName(int index) const { return users[index].name; }
  String getUserPin(int index) const { return users[index].pin; }
  int getUserFID(int index) const { return users[index].fid; }
  int getUserLastDate(int index) const { return users[index].lastCheckDate; }
  
  int findUserByPin(const String &pin) const;
  int findUserByFingerId(int fid) const;
  void updateUserLastDate(int index, int date);
  void setUserFingerprint(int index, int fid);
  
  bool addUser(const String &name, const String &pin);
  bool deleteUser(int index);
  int getNextAvailableFID() const;
  
  void processFingerprintAccess(int userIndex, int scannedFID, DoorController* doorController, TimeManager* timeManager);
  
private:
  void createDefaultUsers();
};

#endif