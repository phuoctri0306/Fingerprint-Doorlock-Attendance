#include "TimeManager.h"

TimeManager::TimeManager() :
  checkStartHour(7), checkStartMin(0),
  checkLateHour(8), checkLateMin(0),
  checkEndHour(11), checkEndMin(0) {}

void TimeManager::setup() {
  configTime(GMT_OFFSET_SEC, 0, NTP_SERVER);
}

void TimeManager::loadSettings() {
  prefs.begin("attendance", true);
  checkStartHour = prefs.getInt("t_start_h", checkStartHour);
  checkStartMin = prefs.getInt("t_start_m", checkStartMin);
  checkLateHour = prefs.getInt("t_late_h", checkLateHour);
  checkLateMin = prefs.getInt("t_late_m", checkLateMin);
  checkEndHour = prefs.getInt("t_end_h", checkEndHour);
  checkEndMin = prefs.getInt("t_end_m", checkEndMin);
  prefs.end();
}

void TimeManager::saveSettings() {
  prefs.begin("attendance", false);
  prefs.putInt("t_start_h", checkStartHour);
  prefs.putInt("t_start_m", checkStartMin);
  prefs.putInt("t_late_h", checkLateHour);
  prefs.putInt("t_late_m", checkLateMin);
  prefs.putInt("t_end_h", checkEndHour);
  prefs.putInt("t_end_m", checkEndMin);
  prefs.end();
}

String TimeManager::getTimeStr() {
  struct tm t;
  if (!getLocalTime(&t)) return "--:--";
  char buf[6];
  strftime(buf, sizeof(buf), "%H:%M", &t);
  return String(buf);
}

String TimeManager::getDateStr() {
  struct tm t;
  if (!getLocalTime(&t)) return "--/--/----";
  char buf[12];
  strftime(buf, sizeof(buf), "%d/%m/%Y", &t);
  return String(buf);
}

String TimeManager::getDayOfWeek() {
  struct tm t;
  if (!getLocalTime(&t)) return "--";
  const char* days[] = {"CN", "T2", "T3", "T4", "T5", "T6", "T7"};
  return String(days[t.tm_wday]);
}

int TimeManager::getHourNow() {
  struct tm t;
  if (!getLocalTime(&t)) return 0;
  return t.tm_hour;
}

int TimeManager::getMinuteNow() {
  struct tm t;
  if (!getLocalTime(&t)) return 0;
  return t.tm_min;
}

int TimeManager::getDateCode() {
  struct tm t;
  if (!getLocalTime(&t)) return 0;
  return (t.tm_year + 1900) * 10000 + (t.tm_mon + 1) * 100 + t.tm_mday;
}

void TimeManager::setTimeSettings(int sh, int sm, int lh, int lm, int eh, int em) {
  checkStartHour = sh;
  checkStartMin = sm;
  checkLateHour = lh;
  checkLateMin = lm;
  checkEndHour = eh;
  checkEndMin = em;
  saveSettings();
}

bool TimeManager::isBeforeStartTime() {
  int nowH = getHourNow();
  int nowM = getMinuteNow();
  int nowTotal = nowH * 60 + nowM;
  int startTotal = checkStartHour * 60 + checkStartMin;
  return nowTotal < startTotal;
}

bool TimeManager::isAfterEndTime() {
  int nowH = getHourNow();
  int nowM = getMinuteNow();
  int nowTotal = nowH * 60 + nowM;
  int endTotal = checkEndHour * 60 + checkEndMin;
  return nowTotal > endTotal;
}

bool TimeManager::isLateTime() {
  int nowH = getHourNow();
  int nowM = getMinuteNow();
  int nowTotal = nowH * 60 + nowM;
  int lateTotal = checkLateHour * 60 + checkLateMin;
  return nowTotal >= lateTotal;
}