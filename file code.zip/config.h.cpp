#ifndef CONFIG_H
#define CONFIG_H

// Pin definitions
#define RELAY_PIN 2
#define BUZZER_PIN 19
#define BUTTON_PIN 15

// Keypad configuration
#define ROWS 4
#define COLS 4

// Time settings
#define GMT_OFFSET_SEC 7 * 3600
#define NTP_SERVER "time.google.com"

// Enrollment settings
#define ENROLL_TIMEOUT_MS 60000UL
#define WAIT_FINGER_TIMEOUT_MS 10000UL
#define DEBOUNCE_TIME 40
#define PULSE_MS 80
#define AP_DISPLAY_INTERVAL 2000

// User settings
#define MAX_USERS 50
#define PIN_LENGTH 5

// AP Settings
#define AP_SSID "ATTENDANCE_SETUP"
#define AP_PASS "12345678"

// Google Sheet
#define SHEET_URL "https://script.google.com/macros/s/AKfycbzsGWa5I7wZ5cIK7wmOheh0Lgwp8e0-m0HCjUiCpVsMX7vFegKRVeil92icdpoV0lwg/exec"
#define SHEET_TOKEN "123456"

#endif