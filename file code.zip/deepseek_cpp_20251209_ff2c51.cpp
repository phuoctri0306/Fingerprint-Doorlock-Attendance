#include "DoorController.h"
#include <WiFi.h>

DoorController::DoorController(LiquidCrystal_I2C* lcd) : lcd(lcd), isLocked(true) {
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
}

void DoorController::unlockDoor() {
  digitalWrite(RELAY_PIN, HIGH);
  isLocked = false;
  beep(250);
  delay(3000);
  lockDoor();
}

void DoorController::lockDoor() {
  digitalWrite(RELAY_PIN, LOW);
  isLocked = true;
}

void DoorController::setLockState(bool locked) {
  if (locked) {
    lockDoor();
  } else {
    unlockDoor();
  }
}

void DoorController::accessGranted(const String &name, const String &id, bool late) {
  lcd->clear();
  lcd->setCursor(0, 0); lcd->print("Xin chao: " + name.substring(0, 16));
  lcd->setCursor(0, 1); lcd->print("Ma: " + id);
  lcd->setCursor(0, 2); lcd->print(late ? "Trang thai: TRE" : "Dung gio");
  lcd->setCursor(0, 3); lcd->print("Mo cua...");

  digitalWrite(RELAY_PIN, HIGH);
  isLocked = false;
  delay(1500);
  lcd->clear();
}

void DoorController::accessDenied(const String &msg) {
  lcd->clear();
  lcd->setCursor(0, 1); lcd->print(msg);
  beep(500);
  delay(700);
  lcd->clear();
}

void DoorController::beep(int duration) {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(duration);
  digitalWrite(BUZZER_PIN, LOW);
}

void DoorController::pulseRising() {
  digitalWrite(RELAY_PIN, LOW);
  delay(10);
  digitalWrite(RELAY_PIN, HIGH);
  delay(PULSE_MS);
  digitalWrite(RELAY_PIN, LOW);
}

void DoorController::pulseFalling() {
  digitalWrite(RELAY_PIN, HIGH);
  delay(10);
  digitalWrite(RELAY_PIN, LOW);
  delay(PULSE_MS);
  digitalWrite(RELAY_PIN, HIGH);
}

void DoorController::sendToSheet(const String &name, const String &id, const String &date, 
                                 const String &time, const String &status) {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  http.begin(SHEET_URL);
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");
  String postData = "token=" + SHEET_TOKEN + "&name=" + name + "&id=" + id + "&date=" + date + "&time=" + time + "&status=" + status;
  int code = http.POST(postData);
  Serial.println("POST to sheet code: " + String(code));
  String resp = http.getString();
  Serial.println("Resp: " + resp);
  http.end();
}