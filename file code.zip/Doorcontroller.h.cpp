#ifndef DOOR_CONTROLLER_H
#define DOOR_CONTROLLER_H

#include <Arduino.h>
#include <LiquidCrystal_I2C.h>
#include <HTTPClient.h>
#include "Config.h"

class DoorController {
private:
  LiquidCrystal_I2C* lcd;
  bool isLocked;
  
public:
  DoorController(LiquidCrystal_I2C* lcd);
  
  void unlockDoor();
  void lockDoor();
  void setLockState(bool locked);
  bool getLockState() const { return isLocked; }
  
  void accessGranted(const String &name, const String &id, bool late = false);
  void accessDenied(const String &msg = "Sai PIN / Van tay");
  
  void beep(int duration = 250);
  void pulseRising();
  void pulseFalling();
  
  void sendToSheet(const String &name, const String &id, const String &date, 
                   const String &time, const String &status);
};

#endif