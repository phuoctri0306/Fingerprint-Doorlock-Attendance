#ifndef WIFI_MANAGER_CUSTOM_H
#define WIFI_MANAGER_CUSTOM_H

#include <Arduino.h>
#include <WiFi.h>
#include <LiquidCrystal_I2C.h>
#include <Preferences.h>
#include "Config.h"

class WiFiManagerCustom {
private:
  LiquidCrystal_I2C* lcd;
  Preferences prefs;
  bool apMode;
  IPAddress apIP;
  unsigned long apDisplayTimer;
  
public:
  WiFiManagerCustom(LiquidCrystal_I2C* lcd);
  
  void connect();
  bool isConnected() const;
  bool isAPMode() const { return apMode; }
  String getLocalIP() const;
  String getAPIP() const;
  
  void updateAPDisplay();
  
private:
  bool connectToSavedWiFi();
  void startAPMode();
  void showAPInfo();
  
  String getSavedSSID();
  String getSavedPassword();
  void saveWiFiCredentials(const String &ssid, const String &password);
};

#endif