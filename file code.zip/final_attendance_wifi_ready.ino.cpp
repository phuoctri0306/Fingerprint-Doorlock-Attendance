#include "AttendanceSystem.h"

AttendanceSystem attendanceSystem;

void setup() {
    attendanceSystem.setup();
}

void loop() {
    attendanceSystem.loop();
}