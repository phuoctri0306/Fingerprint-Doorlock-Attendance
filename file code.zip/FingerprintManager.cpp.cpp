#include "FingerprintManager.h"

FingerprintManager::FingerprintManager() : finger(&Serial2) {}

bool FingerprintManager::begin() {
  Serial2.begin(57600, SERIAL_8N1, RXD2, TXD2);
  finger.begin(57600);
  return verifyPassword();
}

int FingerprintManager::getFingerprintID() {
  uint8_t p = finger.getImage();
  if (p != FINGERPRINT_OK) return -1;
  p = finger.image2Tz();
  if (p != FINGERPRINT_OK) return -1;
  p = finger.fingerSearch();
  if (p != FINGERPRINT_OK) return -1;
  return finger.fingerID;
}

bool FingerprintManager::enrollFingerprint(int id, const String &userName) {
  // Enrollment logic from original code
  // This is a placeholder, you need to implement the full enrollment flow
  return false;
}

bool FingerprintManager::deleteFingerprint(int id) {
  uint8_t p = finger.deleteModel(id);
  return (p == FINGERPRINT_OK);
}

bool FingerprintManager::verifyPassword() {
  return finger.verifyPassword();
}

uint8_t FingerprintManager::waitForFinger(uint16_t timeout) {
  uint32_t start = millis();
  while (millis() - start < timeout) {
    if (finger.getImage() == FINGERPRINT_OK) {
      return FINGERPRINT_OK;
    }
    delay(50);
  }
  return FINGERPRINT_NOFINGER;
}