#include "AttendanceSystem.h"
#include "WiFiManagerCustom.h"
#include "FingerprintManager.h"
#include "DoorController.h"
#include "UserManager.h"
#include "TimeManager.h"
#include "WebInterface.h"

// Keypad setup
const char keysArr[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {32, 33, 25, 26};
byte colPins[COLS] = {27, 14, 12, 13};

AttendanceSystem::AttendanceSystem() :
  lcd(nullptr),
  keypad(nullptr),
  wifiManager(nullptr),
  fingerManager(nullptr),
  doorController(nullptr),
  userManager(nullptr),
  timeManager(nullptr),
  webInterface(nullptr),
  enteredPIN(""),
  waitingA(false),
  enrollActive(false),
  enrollIndex(-1),
  enrollFID(-1),
  enrollStage(0),
  waitForFinger(false),
  waitUserIndex(-1),
  lcdTimer(0),
  isLocked(true),
  lastStable(HIGH),
  lastRaw(HIGH),
  lastDebounce(0) {}

AttendanceSystem::~AttendanceSystem() {
  delete lcd;
  delete keypad;
  delete wifiManager;
  delete fingerManager;
  delete doorController;
  delete userManager;
  delete timeManager;
  delete webInterface;
}

void AttendanceSystem::setup() {
  Serial.begin(115200);
  delay(200);
  
  setupPins();
  setupComponents();
  loadSettings();
  
  // Initial LCD message
  lcd->clear();
  lcd->setCursor(0, 0);
  lcd->print("Booting...");
}

void AttendanceSystem::setupPins() {
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  
  // Initial lock state
  digitalWrite(RELAY_PIN, LOW);   // Locked
  digitalWrite(BUZZER_PIN, LOW);
}

void AttendanceSystem::setupComponents() {
  // Initialize LCD
  Wire.begin(21, 22);
  lcd = new LiquidCrystal_I2C(0x27, 20, 4);
  lcd->init();
  lcd->backlight();
  
  // Initialize Keypad
  keypad = new Keypad(makeKeymap(keysArr), rowPins, colPins, ROWS, COLS);
  
  // Initialize other managers
  userManager = new UserManager();
  timeManager = new TimeManager();
  doorController = new DoorController(lcd);
  wifiManager = new WiFiManagerCustom(lcd);
  fingerManager = new FingerprintManager();
  webInterface = new WebInterface(userManager, doorController, timeManager);
  
  // Setup WiFi
  wifiManager->connect();
  
  // Setup web server
  webInterface->setup();
  
  // Setup time
  timeManager->setup();
  
  // Setup fingerprint
  if (fingerManager->begin()) {
    Serial.println("Fingerprint sensor OK");
  } else {
    Serial.println("Fingerprint sensor not detected or wrong pwd");
  }
}

void AttendanceSystem::loadSettings() {
  userManager->loadFromPrefs();
  timeManager->loadSettings();
}

void AttendanceSystem::loop() {
  // Handle web requests
  webInterface->handleClient();
  
  // Handle enrollment if active
  if (enrollActive) {
    processEnrollment();
  }
  
  // Update LCD periodically
  if (millis() - lcdTimer > 1000) {
    updateLCD();
    lcdTimer = millis();
  }
  
  // Handle button
  handleButton();
  
  // Handle fingerprint waiting
  if (waitForFinger) {
    if (millis() - waitStartMs > WAIT_FINGER_TIMEOUT_MS) {
      waitForFinger = false;
      waitUserIndex = -1;
      doorController->accessDenied("Timeout: No finger");
    } else {
      int fid = fingerManager->getFingerprintID();
      if (fid != -1) {
        Serial.println("Scanned fid = " + String(fid));
        if (waitUserIndex >= 0 && waitUserIndex < userManager->getUserCount()) {
          int expected = userManager->getUserFID(waitUserIndex);
          if (expected >= 0 && fid == expected) {
            int today = timeManager->getDateCode();
            bool alreadyCheckedIn = (userManager->getUserLastDate(waitUserIndex) == today);
            if (alreadyCheckedIn) {
              lcd->clear(); 
              lcd->setCursor(0,1); 
              lcd->print("Mo cua...");
              doorController->setLockState(false); // Unlock
              delay(1500);
              lcd->clear();
            } else {
              if (timeManager->isBeforeStartTime()) {
                doorController->accessDenied("CHUA DEN GIO");
              } else if (timeManager->isAfterEndTime()) {
                doorController->accessDenied("HET GIO DIEM");
              } else {
                bool late = timeManager->isLateTime();
                doorController->accessGranted(userManager->getUserName(waitUserIndex), 
                                               userManager->getUserPin(waitUserIndex), late);
                userManager->updateUserLastDate(waitUserIndex, today);
              }
            }
          } else {
            doorController->accessDenied("VAN TAY KHONG DUNG");
          }
        } else {
          doorController->accessDenied("No user waiting");
        }
        waitForFinger = false;
        waitUserIndex = -1;
        enteredPIN = "";
        delay(300);
      }
    }
  }
  
  // Handle keypad
  char key = keypad->getKey();
  if (key) {
    handleKeypad(key);
  }
  
  delay(10);
}

void AttendanceSystem::handleKeypad(char key) {
  Serial.print("Key: "); Serial.println(key);

  // --- A => chờ * ---
  if (key == 'A') {
    waitingA = true;
    lcd->setCursor(0, 1);
    lcd->print("Nhan * de khoa     ");
  }

  // --- A* => KHÓA ---
  else if (waitingA && key == '*') {
    waitingA = false;

    if (!isLocked) {
      digitalWrite(RELAY_PIN, LOW);   // khóa (nhô chốt)
      isLocked = true;
      doorController->setLockState(true);

      lcd->clear();
      lcd->setCursor(0, 1); 
      lcd->print("KHOA THANH CONG");
    } else {
      digitalWrite(BUZZER_PIN, HIGH); 
      delay(80); 
      digitalWrite(BUZZER_PIN, LOW);

      lcd->clear();
      lcd->setCursor(0, 1); 
      lcd->print("Da khoa san");
    }

    enteredPIN = "";
    delay(80);
  }

  // --- Phím khác A/* → hủy chờ ---
  else if (waitingA && key != 'A' && key != '*') {
    waitingA = false;
  }

  // --- Nhập số ---
  if (key >= '0' && key <= '9') {
    if (enteredPIN.length() < PIN_LENGTH) enteredPIN += key;
    else enteredPIN = "";
  }

  // --- * để xóa ---
  else if (key == '*') {
    if (!waitingA) enteredPIN = "";
  }

  // --- # để submit ---
  else if (key == '#') {
    if (enteredPIN.length() != PIN_LENGTH) {
      digitalWrite(BUZZER_PIN, HIGH); 
      delay(80); 
      digitalWrite(BUZZER_PIN, LOW);
    }
  }

  // --- Display PIN ---
  String mask = "";
  for (int i = 0; i < enteredPIN.length(); i++) mask += '*';
  lcd->setCursor(0, 3); 
  lcd->print("ID: " + mask + "          ");

  // --- Đủ PIN -> xử lý ---
  if (enteredPIN.length() == PIN_LENGTH) {
    int foundIdx = userManager->findUserByPin(enteredPIN);
    
    if (foundIdx >= 0) {
      if (userManager->getUserFID(foundIdx) < 0) {
        lcd->clear(); 
        lcd->setCursor(0, 0); 
        lcd->print("User has no finger");
        lcd->setCursor(0, 1); 
        lcd->print("Enroll first on /admin");
        digitalWrite(BUZZER_PIN, HIGH); 
        delay(300); 
        digitalWrite(BUZZER_PIN, LOW);
        enteredPIN = "";
      } else {
        waitForFinger = true;
        waitUserIndex = foundIdx;
        waitStartMs = millis();

        int today = timeManager->getDateCode();
        bool alreadyCheckedIn = (userManager->getUserLastDate(foundIdx) == today);

        lcd->clear();
        if (alreadyCheckedIn) {
          lcd->setCursor(0, 0); 
          lcd->print("Da diem danh");
          lcd->setCursor(0, 1); 
          lcd->print("Quet van tay de mo");
        } else {
          lcd->setCursor(0, 0); 
          lcd->print("PIN ok: " + userManager->getUserName(foundIdx).substring(0, 16));
          lcd->setCursor(0, 1); 
          lcd->print("Quet van tay 10s...");
          lcd->setCursor(0, 2); 
          lcd->print("Nhan * de huy");
        }
      }
    } else {
      doorController->accessDenied("PIN KHONG HOP LE");
      enteredPIN = "";
    }
  }
}

void AttendanceSystem::processEnrollment() {
  // TODO: Implement enrollment process
}

void AttendanceSystem::handleButton() {
  bool raw = digitalRead(BUTTON_PIN);
  if (raw != lastRaw) {
    lastDebounce = millis();
  }
  if ((millis() - lastDebounce) > DEBOUNCE_TIME) {
    if (raw != lastStable) {
      lastStable = raw;
      if (lastStable == HIGH) {
        isLocked = !isLocked;
        if (isLocked) {
          Serial.println("LOCKED (manual)");
          digitalWrite(RELAY_PIN, LOW);   // khóa
          lcd->clear(); lcd->setCursor(0,1); lcd->print("KHOA - THU CONG");
        } else {
          Serial.println("UNLOCKED (manual)");
          digitalWrite(RELAY_PIN, HIGH);    // mở
          lcd->clear(); lcd->setCursor(0,1); lcd->print("MO - THU CONG");
        }
      }
    }
  }
  lastRaw = raw;
}

void AttendanceSystem::updateLCD() {
  if (!enrollActive && !waitForFinger) {
    if (wifiManager->isAPMode() && WiFi.getMode() == WIFI_AP) {
      wifiManager->updateAPDisplay();
    } else {
      lcd->setCursor(0,0); lcd->print("Ngay: " + timeManager->getDateStr() + "    ");
      lcd->setCursor(0,1); lcd->print("Gio : " + timeManager->getTimeStr() + "    ");
      lcd->setCursor(0,2); lcd->print("Thu : " + timeManager->getDayOfWeek() + "     ");
      String mask=""; for (int i=0;i<enteredPIN.length();i++) mask += '*';
      lcd->setCursor(0,3); lcd->print("ID: " + mask + "           ");
    }
  }
}