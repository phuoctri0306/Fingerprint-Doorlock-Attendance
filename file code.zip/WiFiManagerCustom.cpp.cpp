#include "WiFiManagerCustom.h"

WiFiManagerCustom::WiFiManagerCustom(LiquidCrystal_I2C* lcd) : 
  lcd(lcd), apMode(false), apDisplayTimer(0) {}

void WiFiManagerCustom::connect() {
  String saved_ssid = getSavedSSID();
  String saved_pw = getSavedPassword();
  bool wifiConnected = false;

  WiFi.mode(WIFI_STA);

  if (saved_ssid.length() > 0) {
    Serial.println("Trying saved WiFi: " + saved_ssid);
    WiFi.begin(saved_ssid.c_str(), saved_pw.c_str());
    unsigned long t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < 8000) {
      delay(200);
      Serial.print(".");
    }
    Serial.println();
    if (WiFi.status() == WL_CONNECTED) {
      wifiConnected = true;
      Serial.println("Connected to saved WiFi");
    }
  }

  if (!wifiConnected) {
    startAPMode();
  } else {
    lcd->clear();
    lcd->setCursor(0, 0); lcd->print("Admin:");
    lcd->setCursor(0, 1); lcd->print(WiFi.localIP().toString());
    delay(1500);
    lcd->clear();
  }
}

bool WiFiManagerCustom::connectToSavedWiFi() {
  return false; // Not used in this implementation
}

void WiFiManagerCustom::startAPMode() {
  Serial.println("WiFi failed → starting CONFIG AP");
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  apMode = true;
  apIP = WiFi.softAPIP();
  apDisplayTimer = 0;

  Serial.print("AP IP: ");
  Serial.println(apIP);
  showAPInfo();
}

void WiFiManagerCustom::showAPInfo() {
  lcd->clear();
  lcd->setCursor(0, 0); lcd->print("CONFIG WiFi MODE");
  lcd->setCursor(0, 1); lcd->print("SSID: " + String(AP_SSID));
  lcd->setCursor(0, 2); lcd->print("PASS: " + String(AP_PASS));
  lcd->setCursor(0, 3); lcd->print(apIP.toString());
}

void WiFiManagerCustom::updateAPDisplay() {
  if (apMode && WiFi.getMode() == WIFI_AP) {
    if (millis() - apDisplayTimer > AP_DISPLAY_INTERVAL) {
      apDisplayTimer = millis();
      showAPInfo();
    }
  }
}

bool WiFiManagerCustom::isConnected() const {
  return WiFi.status() == WL_CONNECTED;
}

String WiFiManagerCustom::getLocalIP() const {
  return WiFi.localIP().toString();
}

String WiFiManagerCustom::getAPIP() const {
  return apIP.toString();
}

String WiFiManagerCustom::getSavedSSID() {
  prefs.begin("attendance", true);
  String s = prefs.getString("wifi_ssid", "");
  prefs.end();
  return s;
}

String WiFiManagerCustom::getSavedPassword() {
  prefs.begin("attendance", true);
  String s = prefs.getString("wifi_pw", "");
  prefs.end();
  return s;
}

void WiFiManagerCustom::saveWiFiCredentials(const String &ssid, const String &password) {
  prefs.begin("attendance", false);
  prefs.putString("wifi_ssid", ssid);
  prefs.putString("wifi_pw", password);
  prefs.end();
}