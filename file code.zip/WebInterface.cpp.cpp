#include "WebInterface.h"
#include "Config.h"

WebInterface::WebInterface(UserManager* um, DoorController* dc, TimeManager* tm) 
  : server(80), userManager(um), doorController(dc), timeManager(tm) {}

void WebInterface::setup() {
  server.on("/", HTTP_GET, [this]() { handleRoot(); });
  server.on("/admin", HTTP_GET, [this]() { handleAdmin(); });
  server.on("/add", HTTP_POST, [this]() { handleAddUser(); });
  server.on("/delete", HTTP_POST, [this]() { handleDeleteUser(); });
  server.on("/enroll", HTTP_POST, [this]() { handleEnroll(); });
  server.on("/wifi", HTTP_GET, [this]() { handleWifiPage(); });
  server.on("/wifi_save", HTTP_POST, [this]() { handleWifiSave(); });
  server.on("/set_time", HTTP_POST, [this]() { handleSetTime(); });
  server.begin();
  Serial.println("Web server started");
}

void WebInterface::handleClient() {
  server.handleClient();
}

String WebInterface::htmlHeader(const String &title) {
  String s = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1' />";
  s += "<title>" + title + "</title>";
  s += "<style>body{font-family:Arial,Helvetica,sans-serif;margin:10px}table{border-collapse:collapse;width:100%}th,td{padding:6px;border:1px solid #ccc;text-align:left}th{background:#eee}input[type=text],input[type=number]{width:100%;padding:6px;margin:4px 0}button{padding:8px 10px;background:#0b7dda;color:#fff;border:none;border-radius:4px}a{color:#0b7dda}</style>";
  s += "</head><body>";
  s += "<h2>ESP32 - Admin</h2>";
  return s;
}

String WebInterface::htmlFooter() {
  return "<hr><small>ESP32 Attendance - Web Admin</small></body></html>";
}

void WebInterface::handleRoot() {
  if (WiFi.getMode() == WIFI_AP) {
    server.sendHeader("Location", "/wifi");
    server.send(302, "text/plain", "");
    return;
  }
  server.send(200, "text/plain", "ESP32 Attendance - admin: /admin  wifi: /wifi");
}

void WebInterface::handleAdmin() {
  String html = htmlHeader("Admin");
  html += "<h3>Danh sách người dùng</h3>";
  html += "<table><tr><th>#</th><th>Name</th><th>PIN</th><th>FingerID</th><th>Action</th></tr>";
  for (int i = 0; i < userManager->getUserCount(); i++) {
    String masked = "";
    for (int k = 0; k < userManager->getUserPin(i).length(); k++) masked += '*';
    String fidS = (userManager->getUserFID(i) >= 0) ? String(userManager->getUserFID(i)) : "-";
    html += "<tr><td>" + String(i) + "</td><td>" + userManager->getUserName(i) + "</td><td>" + masked + "</td><td>" + fidS + "</td>";
    html += "<td>";
    html += "<form style='display:inline' method='POST' action='/delete'><input type='hidden' name='index' value='" + String(i) + "'/><button type='submit'>Delete</button></form> ";
    html += "<form style='display:inline' method='POST' action='/enroll'><input type='hidden' name='index' value='" + String(i) + "'/><button type='submit'>Enroll</button></form>";
    html += "</td></tr>";
  }
  html += "</table>";

  html += "<h3>Thêm người dùng</h3>";
  html += "<form method='POST' action='/add'>";
  html += "Name:<br/><input type='text' name='name' required maxlength='40'/><br/>";
  html += "PIN (5 digits):<br/><input type='text' name='pin' pattern='[0-9]{5}' required maxlength='5'/><br/>";
  html += "<button type='submit'>Add user</button></form>";

  html += "<h3>WiFi</h3>";
  html += "<a href='/wifi'>Change WiFi settings</a>";

  html += "<h3>Thời gian điểm danh</h3>";
  html += "<form method='POST' action='/set_time'>";
  html += "Bắt đầu (HH:MM): <input type='number' name='start_h' min='0' max='23' value='" + String(timeManager->getStartHour()) + "'/> : ";
  html += "<input type='number' name='start_m' min='0' max='59' value='" + String(timeManager->getStartMin()) + "'/><br/>";
  html += "Trễ (HH:MM): <input type='number' name='late_h' min='0' max='23' value='" + String(timeManager->getLateHour()) + "'/> : ";
  html += "<input type='number' name='late_m' min='0' max='59' value='" + String(timeManager->getLateMin()) + "'/><br/>";
  html += "Kết thúc (HH:MM): <input type='number' name='end_h' min='0' max='23' value='" + String(timeManager->getEndHour()) + "'/> : ";
  html += "<input type='number' name='end_m' min='0' max='59' value='" + String(timeManager->getEndMin()) + "'/><br/>";
  html += "<button type='submit'>Lưu thời gian</button></form>";

  html += htmlFooter();
  server.send(200, "text/html", html);
}

void WebInterface::handleAddUser() {
  if (server.method() != HTTP_POST) {
    server.send(405, "text/plain", "Method Not Allowed");
    return;
  }
  String name = server.arg("name");
  String pin = server.arg("pin");
  if (pin.length() != PIN_LENGTH) {
    server.send(400, "text/plain", "PIN must be 5 digits");
    return;
  }
  for (int i = 0; i < pin.length(); i++) {
    if (!isDigit(pin.charAt(i))) {
      server.send(400, "text/plain", "PIN digits only");
      return;
    }
  }
  if (!userManager->addUser(name, pin)) {
    server.send(400, "text/plain", "Failed to add user");
    return;
  }
  server.sendHeader("Location", "/admin", true);
  server.send(302, "text/plain", "");
}

void WebInterface::handleDeleteUser() {
  if (server.method() != HTTP_POST) {
    server.send(405, "text/plain", "Method Not Allowed");
    return;
  }
  int idx = server.arg("index").toInt();
  if (!userManager->deleteUser(idx)) {
    server.send(400, "text/plain", "Invalid index");
    return;
  }
  server.sendHeader("Location", "/admin", true);
  server.send(302, "text/plain", "");
}

void WebInterface::handleEnroll() {
  if (server.method() != HTTP_POST) {
    server.send(405, "text/plain", "Method Not Allowed");
    return;
  }
  int idx = server.arg("index").toInt();
  int nextFID = userManager->getNextAvailableFID();
  if (nextFID == -1) {
    server.send(400, "text/plain", "No free FingerID");
    return;
  }
  // TODO: Start enrollment process
  server.sendHeader("Location", "/admin", true);
  server.send(302, "text/plain", "");
}

void WebInterface::handleWifiPage() {
  String cur_ssid = ""; // Get from WiFiManager
  String html = htmlHeader("WiFi");
  html += "<h3>Change WiFi</h3>";
  html += "<form method='POST' action='/wifi_save'>";
  html += "SSID:<br/><input type='text' name='ssid' required value='" + cur_ssid + "' maxlength='64'/><br/>";
  html += "Password:<br/><input type='text' name='pass' maxlength='64'/><br/>";
  html += "<button type='submit'>Save & Reboot</button></form>";
  html += "<p><a href='/admin'>Back to admin</a></p>";
  html += htmlFooter();
  server.send(200, "text/html", html);
}

void WebInterface::handleWifiSave() {
  if (server.method() != HTTP_POST) {
    server.send(405, "text/plain", "Method Not Allowed");
    return;
  }
  String ssid = server.arg("ssid");
  String pass = server.arg("pass");
  // TODO: Save WiFi credentials
  server.send(200, "text/html", "<html><body><h3>Saved WiFi. Device will reboot...</h3><p>You can close this page.</p></body></html>");
  delay(500);
  ESP.restart();
}

void WebInterface::handleSetTime() {
  if (server.method() != HTTP_POST) {
    server.send(405, "text/plain", "Method Not Allowed");
    return;
  }
  int sh = server.arg("start_h").toInt();
  int sm = server.arg("start_m").toInt();
  int lh = server.arg("late_h").toInt();
  int lm = server.arg("late_m").toInt();
  int eh = server.arg("end_h").toInt();
  int em = server.arg("end_m").toInt();

  if (sh < 0) sh = 0; if (sh > 23) sh = 23;
  if (lh < 0) lh = 0; if (lh > 23) lh = 23;
  if (eh < 0) eh = 0; if (eh > 23) eh = 23;
  if (sm < 0) sm = 0; if (sm > 59) sm = 59;
  if (lm < 0) lm = 0; if (lm > 59) lm = 59;
  if (em < 0) em = 0; if (em > 59) em = 59;

  timeManager->setTimeSettings(sh, sm, lh, lm, eh, em);
  server.sendHeader("Location", "/admin", true);
  server.send(302, "text/plain", "");
}